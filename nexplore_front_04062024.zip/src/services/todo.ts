import { CreateTodoType } from "../types/ApiTypesd";
import { Todo, TodoId } from "../types/Todo";

export const getTodoList = async (): Promise<[Error?, Todo[]?]> => {
  try {
    const res = await fetch("http://localhost:3000/api/todos");
    if (!res.ok) return [new Error("Error en la petición GET /api/todos")];
    const json = (await res.json()) as Todo[];
    return [undefined, json];
  } catch (error) {
    if (error instanceof Error) return [error];
    return [new Error("Unknown error")];
  }
};

export const createTodo = async (
  todo: CreateTodoType
): Promise<[Error?, Todo?]> => {
  try {
    const res = await fetch("http://localhost:3000/api/todos", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(todo),
    });
    if (!res.ok) {
      return [new Error("Error al crear el todo")];
    }
    const json = await res.json();
    return [undefined, json];
  } catch (error) {
    if (error instanceof Error) return [error];
    return [new Error("Unknown error")];
  }
};

export const updateTodo = async (
  id: string,
  newCompleted?: boolean,
  newName?: string
): Promise<[Error?, Todo?]> => {
  try {
    const newBody = {} as { newName: string; newCompleted: boolean };
    if (newName) {
      newBody.newName = newName;
    }
    if (newCompleted) {
      newBody.newCompleted = newCompleted;
    }

    const res = await fetch(`http://localhost:3000/api/todos/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newBody),
    });
    if (!res.ok) {
      return [new Error("Error al actualizar el todo")];
    }
    const json = await res.json();
    return [undefined, json];
  } catch (error) {
    if (error instanceof Error) return [error];
    return [new Error("Unknown error")];
  }
};

export const deleteTodo = async ({ id }: TodoId): Promise<[Error?, Todo?]> => {
  try {
    const res = await fetch(`http://localhost:3000/api/todos/${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
      },
    });
    if (!res.ok) {
      return [new Error("Error al borrar el todo")];
    }
    const json = await res.json();
    return [undefined, json];
  } catch (error) {
    if (error instanceof Error) return [error];
    return [new Error("Unknown error")];
  }
};
