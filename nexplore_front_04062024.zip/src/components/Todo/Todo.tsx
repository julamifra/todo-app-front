import React from "react";
import { TodoProps } from "../../types/Todo";
import styles from "./Todo.module.scss";

function Todo({
  id,
  name,
  completed,
  onRemoveTodo,
  onToggleComplete,
}: TodoProps) {
  const handleChangeCheckbox = (
    event: React.ChangeEvent<HTMLInputElement>
  ): void => {
    onToggleComplete({ id, completed: event.target.checked });
  };

  return (
    <div className={styles.todo}>
      <input
        type="checkbox"
        checked={completed}
        onChange={handleChangeCheckbox}
      ></input>
      <label style={{ textDecoration: completed ? "line-through" : "" }}>
        {name}
      </label>
      <button onClick={() => onRemoveTodo({ id })}></button>
    </div>
  );
}

export default Todo;
