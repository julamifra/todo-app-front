import "./App.css";
import TodoList from "./components/TodoList/TodoList";
import Header from "./components/Header";
import { useTodos } from "./hooks/useTodoList";

function App() {
  const { todoList, handleCompleted, handleRemove, handleOnAddTodo } =
    useTodos();

  return (
    <>
      <Header onAddTodo={handleOnAddTodo}></Header>
      <TodoList
        onRemoveTodo={handleRemove}
        onToggleComplete={handleCompleted}
        todoList={todoList}
      />
    </>
  );
}

export default App;
