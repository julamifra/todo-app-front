import { Todo } from "./Todo";

export type CreateTodoType = Pick<Todo, "name">;
